<!--
 * @Author: xuanyu
 * @LastEditors: xuanyu
 * @email: 969718197@qq.com
 * @github: https://github.com/z-xuanyu
 * @Date: 2021-12-02 15:59:51
 * @LastEditTime: 2021-12-02 17:01:09
 * @Description: Modify here please
-->
<script setup></script>
<template>
  <h1 class="text-5xl text-center text-gray-500 py-28">ABOUT</h1>
  <div class="h-60 md:h-96 about-bg"></div>
  <div class="max-w-4xl py-20 mx-auto my-0 md:py-40 px-14 md:px-0">
    <div class="mb-20 space-y-4 text-xl text-center md:text-lg">
      <h4>新しい「コラボレーション」</h4>
      <h4>クリエイティブな「楽しみ方」</h4>
      <h4>斬新な「SAKE」スタイル</h4>
    </div>
    <div class="text-xl leading-10 text-gray-500 md:pl-20 md:text-md">
      <p>
        「おいしいSAKEを世界へ」というメッセージを掲げ、海琳堂は2013年にスタートしました。
      </p>
      <p class="mb-10">そしていま「SAKE」は急速に進化し、世界中を虜にしています。</p>
      <p>職人の手によって丁寧に醸された美しい日本酒。</p>
      <p>郷土文化に根ざし愛され続ける世界中の酒の数々。</p>
      <p>
        私たち海琳堂も、多様性にあふれた個性的な「SAKE」のような存在であり続けたいと思っていま
      </p>
    </div>
  </div>
</template>
<style scoped>
.about-bg {
  background: url("http://www.kairindo.co.jp/wp/wp-content/themes/kairindo/images/about_jp.jpg")
    center;
}
</style>
