<!--
 * @Author: xuanyu
 * @LastEditors: xuanyu
 * @email: 969718197@qq.com
 * @github: https://github.com/z-xuanyu
 * @Date: 2021-12-01 14:38:11
 * @LastEditTime: 2021-12-02 15:40:30
 * @Description: Modify here please
-->
<script setup></script>
<template>
  <footer class="flex justify-center p-5 bg-gray-900 border-t xl:p-14 footer">
    <div class="justify-between w-full text-white xl:w-8/12 xl:flex">
        <div class="text-center xl:w-3/12 footer-logo">
            <img class="w-40 mx-auto my-0" src="http://www.kairindo.co.jp/wp/wp-content/themes/kairindo/images/logo_color.png" alt="">
            <p class="mt-3 text-sm text-gray-500">样式社会海菱碳</p>
        </div>
        <div class="hidden xl:block">
            <ul class="flex flex-1 space-x-10 text-sm text-gray-500">
            <li><a href="#">会社概要</a></li>
            <li><a href="#">プライバシーポリシー</a></li>
            <li><a href="#">お問い合せ</a></li>
        </ul>
        </div>
        <div class="flex items-center xl:w-3/12">
            <img class="w-20 h-32" src="http://www.kairindo.co.jp/wp/wp-content/themes/kairindo/images/bottle.png" alt="">
            <p class="pt-1 pl-4 text-sm text-gray-500">お酒は20歳になってから。飲酒運転は法律で禁止されています。妊娠中や授乳期の飲酒は胎児・乳児の発育に悪影響を与えるおそれがあります。お酒は楽しくほどほどに。</p>
        </div>
    </div>
  </footer>
</template>
